import React, { useState } from "react";
import NavItem from "./NavItem";
import menuItems from "./menuItem";

const MenuItems = ({ isMobile, closeMobileMenu }) => {
  const [openMenuKey, setOpenMenuKey] = useState(null);
  return menuItems.map((item, index) => (
    <NavItem
      key={item.path || index}
      item={item}
      isMobile={isMobile}
      closeMobileMenu={closeMobileMenu}
      depthLevel={0}
      openMenuKey={openMenuKey}
      setOpenMenuKey={setOpenMenuKey}
    />
  ));
};

export default React.memo(MenuItems);
